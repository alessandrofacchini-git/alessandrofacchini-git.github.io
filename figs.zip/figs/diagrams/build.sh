#!/bin/bash
# build one or all diagrams: ./build.sh d01_three_layers  (or no arg = all)
S="C:/Users/alefa/AppData/Local/Temp/claude/C--Users-alefa-OneDrive-1TB-A-OneDrive-MASTER-BMELA---BA-Ph-2026-SOP-ideas/22833b1e-2103-453c-8f0e-e1dbf17dc031/scratchpad"
for f in ${1:-$(ls d*.tex | sed 's/\.tex$//')}; do
  pdflatex -interaction=nonstopmode -halt-on-error "$f.tex" > "$f.buildlog" 2>&1 && echo "OK  $f" || { echo "ERR $f"; grep -n "^!" -A3 "$f.buildlog" | head -20; }
  rm -f "$f.aux" "$f.log"
  python -c "import fitz; d=fitz.open('$f.pdf'); d[0].get_pixmap(matrix=fitz.Matrix(1.6,1.6)).save('$S/$f.png')" 2>/dev/null
done
