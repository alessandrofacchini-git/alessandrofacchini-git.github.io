# Diagrams for the v4 paper (TikZ, standalone)

Each `dNN_*.tex` compiles on its own (`pdflatex dNN_name.tex`), shares the palette and
styles in `dxstyle.tex`, and produces `dNN_name.pdf` for `\includegraphics`. `bash build.sh`
compiles all (or `bash build.sh d01_three_layers` for one). Numbers inside the diagrams are
the paper's own (source block named in each file's header comment).

| file | what it shows | where it goes |
|---|---|---|
| d01_three_layers | one present-bias factor, three readings of the same choices (state / structure / good) | intro, both papers |
| d02_axes | the three axes (structure x good x state, flat grid) and where the literatures and the three designs sit | sec 2 |
| d03_vantage | the vantage timeline: beta cancels at the advance vantage; Gamma | sec 2 / sec 9 |
| d04_ladder | the restriction ladder as a table: rung -> restriction -> weight -> where -> verdict | sec 3 |
| d05_exposure | the A&R day as slots + block; expected treatment mu; what Borusyak-Hull recentring changes and what survives | sec 6.1 |
| d07_tilt_vs_shift | a trait shifts the whole profile; drinking/smoking tilts it toward money | sec 7.3 |
| d08_betaeff_margins | beta_eff margin by margin (replaces the one-axis schematic); proximity apart | sec 6.5 / sec 10 |
| d09_msc | the MSC architecture, restyled; beta_eff derived | sec 10 |
| d10_welfare | the convergence rule for Gamma; the certifier decomposed (belief = truth + error) | sec 9 |
| d11_masquerade | seven mechanisms, the switch for each, what it returned (liquidity row = Kaur 2024 bound) | sec 5.4 |
| d12_roadmap | the argument in one picture, with the three verdicts | intro (short paper) |

AF picks which to keep. PNG previews are in the scratchpad; regenerate with build.sh.
